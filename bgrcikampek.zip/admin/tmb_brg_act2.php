<?php 
include 'config.php';
$perusahaan=$_POST['perusahaan'];
$no_spk=$_POST['no_spk'];
$tgl_spk=$_POST['tgl_spk'];
$asal_brg=$_POST['asal_brg'];
$Tujuan_brg=$_POST['tujuan_brg'];
$jml_rit=$_POST['jml_rit'];
$hrg_rit=$_POST['hrg_rit'];
$nilai_spk=$_POST['nilai_spk'];
$sisa_rit=$_POST['sisa_rit'];

mysql_query("insert into tb_spk values('','$perusahaan','$no_spk','$tgl_spk','$asal_brg','$tujuan_brg','$jml_rit','$hrg_rit','$nilai_spk','$sisa_rit')");
header("location:barang2.php");

 ?>