<?php 
$cari=$_GET['cari'];
header("location:barang2.php?cari=$cari");
?>