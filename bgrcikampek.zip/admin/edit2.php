<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit SPK</h3>
<a class="btn" href="barang.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_brg=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from tb_spk where id='$id_brg'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="update2.php" method="post">
		<table class="table">
			<tr>
				<td></td>
				<td><input type="hidden" name="id" value="<?php echo $d['id'] ?>"></td>
			</tr>
			<tr>
				<td>Nama Perusahaan</td>
				<td><input type="text" class="form-control" name="perusahaan" value="<?php echo $d['perusahaan'] ?>"></td>
			</tr>
			<tr>
				<td>No SPK</td>
				<td><input type="text" class="form-control" name="no_spk" value="<?php echo $d['no_spk'] ?>"></td>
			</tr>
			<tr>
				<td>Tanggal SPK</td>
				<td><input type="text" class="form-control" name="tgl_spk" value="<?php echo $d['tgl_spk'] ?>"></td>
			</tr>
			<tr>
				<td>Asal Barang</td>
				<td><input type="text" class="form-control" name="asal_brg" value="<?php echo $d['asal_brg'] ?>"></td>
			</tr>
			<tr>
				<td>Tujuan Barang</td>
				<td><input type="text" class="form-control" name="tujuan_brg" value="<?php echo $d['tujuan_brg'] ?>"></td>
			</tr>
			<tr>
				<td>Jumlah rit</td>
				<td><input type="text" class="form-control" name="jml_rit" value="<?php echo $d['jml_rit'] ?>"></td>
			</tr>
			<tr>
			<tr>
				<td>Harga/rit</td>
				<td><input type="text" class="form-control" name="hrg_rit" value="<?php echo $d['hrg_rit'] ?>"></td>
			</tr>
			<tr>
				<td>Nilai SPK</td>
				<td><input type="text" class="form-control" name="nilai_spk" value="<?php echo $d['nilai_spk'] ?>"></td>
			</tr>
			<tr>
				<td> Sisa rit</td>
				<td><input type="text" class="form-control" name="sisa_rit" value="<?php echo $d['sisa_rit'] ?>"></td>
			</tr>
			<tr>
			<tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>
<?php include 'footer.php'; ?>