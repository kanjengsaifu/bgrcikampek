<?php 
include 'config.php';
$id=$_POST['id'];
$nm_vendor=$_POST['nm_vendor'];
$no_spk=$_POST['no_spk'];
$tgl_spk=$_POST['tgl_spk'];
$asal_brg=$_POST['asal_brg'];
$Tujuan_brg=$_POST['Tujuan_brg'];
$hrg_rit=$_POST['hrg_rit'];

mysql_query("update tb_vendor set nm_vendor='$nm_vendor', no_spk='$no_spk', tgl_spk='$tgl_spk', asal_brg='$asal_brg', Tujuan_brg='$Tujuan_brg', hrg_rit='$hrg_rit' where id='$id'");
header("location:barang.php");

?>