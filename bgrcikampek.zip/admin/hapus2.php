<?php 
include 'config.php';
$id=$_GET['id'];
mysql_query("delete from tb_spk where id='$id'");
header("location:barang2.php");

?>