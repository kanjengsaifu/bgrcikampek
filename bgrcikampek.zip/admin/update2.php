<?php 
include 'config.php';
$id=$_POST['id'];
$perusahaan=$_POST['perusahaan'];
$no_spk=$_POST['no_spk'];
$tgl_spk=$_POST['tgl_spk'];
$asal_brg=$_POST['asal_brg'];
$tujuan_brg=$_POST['tujuan_brg'];
$jml_rit=$_POST['jml_rit'];
$hrg_rit=$_POST['hrg_rit'];
$nilai_spk=$_POST['nilai_spk'];
$sisa_rit=$_POST['sisa_rit'];

mysql_query("update tb_spk set perusahaan='$perusahaan', no_spk='$no_spk', tgl_spk='$tgl_spk', asal_brg='$asal_brg', tujuan_brg='$tujuan_brg', jml_rit='$jml_rit', hrg_rit='$hrg_rit', nilai_spk='$nilai_spk', sisa_rit='$sisa_rit' where id='$id'");
header("location:barang2.php");

?>