<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit Data Vendor</h3>
<a class="btn" href="barang.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_brg=mysql_real_escape_string($_GET['id']);
$det=mysql_query("select * from tb_vendor where id='$id_brg'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
?>					
	<form action="update.php" method="post">
		<table class="table">
			<tr>
				<td></td>
				<td><input type="hidden" name="id" value="<?php echo $d['id'] ?>"></td>
			</tr>
			<tr>
				<td>Nama Vendor</td>
				<td><input type="text" class="form-control" name="nm_vendor" value="<?php echo $d['nm_vendor'] ?>"></td>
			</tr>
			<tr>
				<td>No SPK</td>
				<td><input type="text" class="form-control" name="no_spk" value="<?php echo $d['no_spk'] ?>"></td>
			</tr>
			<tr>
				<td>Tanggal SPK</td>
				<td><input type="text" class="form-control" name="tgl_spk" value="<?php echo $d['tgl_spk'] ?>"></td>
			</tr>
			<tr>
				<td>Asal Barang</td>
				<td><input type="text" class="form-control" name="asal_brg" value="<?php echo $d['asal_brg'] ?>"></td>
			</tr>
			<tr>
				<td>Tujuan Barang</td>
				<td><input type="text" class="form-control" name="Tujuan_brg" value="<?php echo $d['Tujuan_brg'] ?>"></td>
			</tr>
			<tr>
				<td>Harga/rit</td>
				<td><input type="text" class="form-control" name="hrg_rit" value="<?php echo $d['hrg_rit'] ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>
<?php include 'footer.php'; ?>