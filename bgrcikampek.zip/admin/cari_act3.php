<?php 
$cari=$_GET['cari'];
header("location:barang3.php?cari=$cari");
?>