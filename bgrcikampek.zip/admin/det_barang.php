<?php 
include 'header.php';
?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Detail Barang</h3>
<a class="btn" href="barang.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>

<?php
$id=mysql_real_escape_string($_GET['id']);


$det=mysql_query("select * from tb_vendor where id='$id'")or die(mysql_error());
while($d=mysql_fetch_array($det)){
	?>					
	<table class="table">
		<tr>
			<td>Nama Vendor</td>
			<td><?php echo $d['nm_vendor'] ?></td>
		</tr>
		<tr>
			<td>No SPK</td>
			<td><?php echo $d['no_spk'] ?></td>
		</tr>
		<tr>
			<td>Tanggal SPK</td>
			<td><?php echo $d['tgl_spk'] ?></td>
		</tr>
		<tr>
			<td>Asal Barang</td>
			<td><?php echo $d['asal_brg'] ?></td>
		</tr>
			<tr>
			<td>Tujuan Barang</td>
			<td><?php echo $d['Tujuan_brg'] ?></td>
		</tr>
		<tr>
			<td>Harga/rit</td>
			<td>Rp.<?php echo number_format($d['hrg_rit']) ?>,-</td>
		</tr>
	</table>
	<?php 
}
?>
<?php include 'footer.php'; ?>