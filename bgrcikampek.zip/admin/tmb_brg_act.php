<?php 
include 'config.php';
$nm_vendor=$_POST['nm_vendor'];
$no_spk=$_POST['no_spk'];
$tgl_spk=$_POST['tgl_spk'];
$asal_brg=$_POST['asal_brg'];
$Tujuan_brg=$_POST['Tujuan_brg'];
$hrg_rit=$_POST['hrg_rit'];


mysql_query("insert into tb_vendor values('','$nm_vendor','$no_spk','$tgl_spk','$asal_brg','$Tujuan_brg','$hrg_rit')");
header("location:barang.php");

 ?>